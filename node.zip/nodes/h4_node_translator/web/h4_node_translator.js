import { app } from "../../scripts/app.js";
import { api } from "../../scripts/api.js";

// H4_NodeTranslator
// Scans the graph for "H4_NodeTranslator" nodes.
// If active, fetches translations and applies them to node titles and widgets.

const ID_TRANSLATOR = "H4_NodeTranslator";

app.registerExtension({
    name: "h4.NodeTranslator",

    // State
    _translations: null, // Cache
    _activeLang: null,
    _isActive: false,
    _lastCheck: 0,

    async setup() {
        console.log("🌐 H4 Node Translator Loaded.");

        // Use arrow function in setInterval to preserve 'this' and catch async errors
        setInterval(() => this.checkTranslatorState().catch(e => console.error("[H4 Translator] Loop Error:", e)), 1000);
    },

    async checkTranslatorState() {
        if (!app.graph) return;

        // Find our control node
        const translatorNode = app.graph.findNodesByType(ID_TRANSLATOR)?.[0];

        if (!translatorNode) {
            if (this._isActive) {
                this.revertTranslations();
            }
            this._isActive = false;
            return;
        }

        // Get settings
        const langWidget = translatorNode.widgets?.find(w => w.name === "language");
        const modeWidget = translatorNode.widgets?.find(w => w.name === "mode");

        if (!langWidget || !modeWidget) return;

        const mode = modeWidget.value;
        if (mode === "Disabled") {
            if (this._isActive) this.revertTranslations();
            this._isActive = false;
            return;
        }

        // Parse Language (e.g., "Spanish (es)" -> "es")
        const langRaw = langWidget.value;
        const match = langRaw.match(/\((.*?)\)/);
        const langCode = match ? match[1] : null;

        if (!langCode) return;

        // If language changed or just activated
        if (langCode !== this._activeLang || !this._isActive) {
            console.log(`🌐 [H4 Translator] Activating Language: ${langCode}`);
            this._activeLang = langCode;
            this._isActive = true;

            if (!this._translations) {
                await this.loadTranslations();
            }
        }

        // Continuously apply for new nodes
        this.applyTranslations();
    },

    async loadTranslations() {
        try {
            const resp = await api.fetchApi("/h4/translations");
            if (resp.ok) {
                this._translations = await resp.json();
                console.log(`🌐 [H4 Translator] Loaded definition data keys: ${Object.keys(this._translations).length}`);
            }
        } catch (e) {
            console.error("🌐 [H4 Translator] Failed to load translations:", e);
        }
    },

    applyTranslations() {
        if (!this._translations || !this._isActive || !app.graph) return;

        const lang = this._activeLang;
        let changed = false;

        app.graph._nodes.forEach(node => {
            // Skip the translator itself
            if (node.type === ID_TRANSLATOR) return;

            // Look up node type in dictionary
            const def = this._translations[node.type];
            if (!def || !def[lang]) return;

            const target = def[lang];

            if (!node._h4_original_title) node._h4_original_title = node.title;

            // Only update if target title is defined
            if (target.title && node.title !== target.title) {
                node.title = target.title;
                changed = true;
            }

            // 2. Translate Widgets (Visual Label Only)
            if (target.widgets && node.widgets) {
                node.widgets.forEach(w => {
                    const translatedLabel = target.widgets[w.name];
                    if (translatedLabel) {
                        if (!w._h4_original_label) w._h4_original_label = w.label || w.name;

                        if (w.label !== translatedLabel) {
                            w.label = translatedLabel;
                            changed = true;
                        }
                    }
                });
            }
        });

        // Force redraw ONLY if something changed
        if (changed) {
            app.graph.setDirtyCanvas(true, true);
        }

        // Global UI DOM translation
        if (this._translations["Global_UI"] && this._translations["Global_UI"][lang]) {
            this.translateGlobalUI(this._translations["Global_UI"][lang]);
        }
    },

    translateGlobalUI(dict) {
        // We only want to set this up once per active session
        if (!this._uiObserver) {
            console.log("🌐 [H4 Translator] Starting DOM Observer for Menus and Search");
            this._uiObserver = new MutationObserver((mutations) => {
                if (!this._isActive || !this._activeLang || !this._translations["Global_UI"]) return;
                const d = this._translations["Global_UI"][this._activeLang];
                if (!d) return;

                // Simple text replacement function for specific nodes
                const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null, false);
                let node;
                while (node = walker.nextNode()) {
                    // Only process text nodes inside Comfy UI popups/menus/search
                    if (node.parentElement &&
                        (node.parentElement.closest(".lite-searchbox") ||
                            node.parentElement.closest(".litegraph.lite-contextmenu") ||
                            node.parentElement.closest(".comfy-menu") ||
                            node.parentElement.closest(".dialog") ||
                            node.parentElement.tagName === "BUTTON")) {

                        const text = node.nodeValue.trim();
                        if (text && d[text]) {
                            // Store original to revert later if needed
                            if (!node.parentElement._h4_original_text) {
                                node.parentElement._h4_original_text = text;
                            }
                            node.nodeValue = node.nodeValue.replace(text, d[text]);
                        }
                    }
                }
            });

            // Observe body for added menus/dialogs
            this._uiObserver.observe(document.body, { childList: true, subtree: true });
        }

        // Run an initial pass right now
        // Trigger a dummy mutation to force the observer to walk existing text
        document.body.appendChild(document.createElement("span")).remove();
    },

    revertTranslations() {
        if (!this._originalStore) return;

        console.log("🇪🇸 -> 🇬🇧 [H4 Translator] Reverting to origin...");
        let changed = false;

        // Revert global UI text
        const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null, false);
        let node;
        while (node = walker.nextNode()) {
            if (node.parentElement && node.parentElement._h4_original_text) {
                node.nodeValue = node.parentElement._h4_original_text;
                delete node.parentElement._h4_original_text;
            }
        }

        if (!app.graph) return; // Keep this check for graph-related reverts

        app.graph._nodes.forEach(node => {
            // Restore Title
            if (node._h4_original_title) {
                node.title = node._h4_original_title;
                delete node._h4_original_title;
            }

            // Restore Widgets
            if (node.widgets) {
                node.widgets.forEach(w => {
                    if (w._h4_original_label) {
                        w.label = w._h4_original_label;
                        delete w._h4_original_label;
                    }
                });
            }
        });

        app.graph.setDirtyCanvas(true, true);
    }
});
