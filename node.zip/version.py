# FILE: custom_nodes/comfyui_h4_live/version.py
# ------------------------------------------------------------------------------
# h4_Live Version Control
# ------------------------------------------------------------------------------

__version__ = "2.0.0"
__author__ = "(h4)"
__status__ = "Alpha - Nuclear Option - Scortched Eart - No Mercy - No Forgiveness"
