# FILE: custom_nodes/comfyui_h4_live/version.py
# ------------------------------------------------------------------------------
# h4_Live Version Control
# ------------------------------------------------------------------------------

__version__ = "2.5.2-beta"
__author__ = "(h4)"
__status__ = "Beta - Nuclear Logic - Persistent State"
